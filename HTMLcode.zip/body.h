#ifndef _BODY_
#define _BODY_

#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"

#endif
void img(FILE *);
void head1(FILE *);
void body(FILE *);