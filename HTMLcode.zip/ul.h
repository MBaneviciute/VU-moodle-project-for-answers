#ifndef _UL_
#define _UL_

#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"

#endif

void ul1(FILE *);
void ul2(FILE *);