#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"

void head(FILE *linker)
{
    fprintf(linker,"%s","<head>\n"
    "\t<meta charset=\"UTF-8\">\n"
    "\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n"
    "\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
    "\t<link rel=\"stylesheet\" href=\"styles.css\">\n"
    "\t<link rel=\"shortcut icon\" href=\"https://emokymai.vu.lt/theme/image.php/maker/theme/1634296690/favicon\">\n"
    "\t<title>Course: Programavimo pagrindai (I.Radavičius, paskaitos/pratybos)</title>\n"
    "</head>");
}