#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"

void html(FILE *linker)
{
    fprintf(linker, "%s", "<html lang=\"en\">\n");
    head(linker);
    body(linker);
    fprintf(linker,"%s","</html>\n");
}