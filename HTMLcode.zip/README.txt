Just run the output.exe and add the information you are asked to add, then the .html file will be created

Enjoy :)