#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"
#include "FAQ_CREATE.h"

void img(FILE *linker)
{
    fprintf(linker,"%s","\t\t\t\t\t<img class=\"vu-logo\"\n"
    "\t\t\t\t\t\tsrc=\"https://emokymai.vu.lt/pluginfile.php/1/theme_maker/logo/1634296690/VU_VMA_2%287%29%20%281%29.png\"\n"
    "\t\t\t\t\t\talt=\"vu logo\">\n");

}
void head1(FILE *linker)
{
    fprintf(linker,"%s","\t\t\t\t\t\t <h1 class=\"course-header-title\">\n"
    "\t\t\t\t\t\t\tProgramavimo pagrindai (I.Radavičius, paskaitos/pratybos)\n"
    "\t\t\t\t\t\t</h1>\n");
}
void body(FILE *linker)
{
    fprintf(linker, "%s", "<body>\n"
    "\t<div class=\"page\">\n"
    "\t\t<header class=\"page-header\">\n"
    "\t\t\t<div class=\"top-bar\">\n"
    "\t\t\t</div>\n"
    "\t\t\t<div class=\"bottom-bar\">\n"
    "\t\t\t\t<div class=\"bottom-bar-container\">\n");
    img(linker);
    ul1(linker);
    fprintf(linker,"%s","\t\t\t\t</div>\n"
    "\t\t\t</div>\n"
    "\t\t\t<div class=\"course-header-image\">\n"
    "\t\t\t\t<div class=\"course-header-image-container\">\n"
    "\t\t\t\t\t<div class=\"course-header-box\">\n");
    head1(linker);
    fprintf(linker, "%s","\t\t\t\t\t</div>\n"
    "\t\t\t\t\t<div class=\"course-header-box\">\n");
    ul2(linker);
    fprintf(linker,"%s","\t\t\t\t\t</div>\n"
    "\t\t\t\t</div>\n"
    "\t\t\t</div>\n"
    "\t\t</header>\n");
    section(linker);
    fprintf(linker, "%s", "\t</div>\n");
    footer(linker);
    fprintf(linker, "%s", "</body>");
}