Just run the output.exe and add the information you are asked to add, then the .html file will be created
Open the C_project.html file;

If linking faults, extract the object files from the file and then try to link them and create an exe file.

P.S you can check out the architecture of the given program.(provided in the architecture folder);

Enjoy :)
