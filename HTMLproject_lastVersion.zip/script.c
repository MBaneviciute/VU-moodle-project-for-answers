#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"
#include "FAQ_CREATE.h"

void constants1(FILE *linker)
{
    fprintf(linker, "%s", "\tconst content = document.getElementById('content');\n"
    "\tconst testTitle = document.getElementById('miniTestTitle');\n"
    "\tconst firstTestImages = [];\n"
    "\tconst secondTestImages = ['2_testas/1.png', '2_testas/2.png', '2_testas/3.png', '2_testas/4.png', '2_testas/5.png', '2_testas/6.png', '2_testas/7.png', '2_testas/8.png'];\n"
    "\tconst thirdTestImages = ['3_testas/1.png', '3_testas/2.png', '3_testas/3.png', '3_testas/4.png', '3_testas/5.png', '3_testas/6.png', '3_testas/7.png', '3_testas/8.png', '3_testas/9.png'];\n"
    "\tconst fourthTestImages = ['4_testas/1.png', '4_testas/2.png', '4_testas/3.png', '4_testas/4.png', '4_testas/5.png', '4_testas/6.png', '4_testas/7.png', '4_testas/8.png', '4_testas/9.png', '4_testas/10.png'];\n"
    "\tconst fifthTestImages = ['5_testas/1.png', '5_testas/2.png', '5_testas/3.png', '5_testas/4.png', '5_testas/5.png', '5_testas/6.png', '5_testas/7.png', '5_testas/8.png', '5_testas/9.png', '5_testas/10.png'];\n");
}
void script(FILE *linker, char *file_name, int index)
{
    fprintf(linker, "%s", "<script>\n");
    constants1(linker);
    fprintf(linker, "\tconst titleText = document.createTextNode(`Minitestas ${%d}`)\n",index);
    fprintf(linker,"%s","\ttestTitle.appendChild(titleText);\n"
    "\tconst ADDITIONAL_NUMBER_TO_ADD = 1;\n");
    fprintf(linker,"%s.map((item, index) => {\n"
    "\t\tconst title = document.createElement('p');\n"
    "\t\tconst image = document.createElement('img');\n"
    "\t\tconst text = document.createTextNode(`${index + ADDITIONAL_NUMBER_TO_ADD}. Užduotis`);\n"
    "\t\ttitle.appendChild(text);\n"
    "\t\ttitle.className = \"mini-test\"\n"
    "\t\tcontent.appendChild(title);\n"
    "\t\timage.setAttribute(\"src\", item);\n"
    "\t\timage.style.width = '450px';\n"
    "\t\timage.style.height = 'auto';\n"
    "\t\timage.style.marginBottom = '45px';\n"
    "\t\tcontent.appendChild(image);\n"
    "\t});\n",file_name);
    fprintf(linker,"%s","</script>\n");
}