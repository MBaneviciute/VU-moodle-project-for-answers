#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"
#include "FAQ_CREATE.h"

void head3(FILE *linker)
{
    fprintf(linker,"%s","\t\t\t<h3>\n"
    "\t\t\t\t<span>\n"
    "\t\t\t\t\t<a class=\"main-container-title\" href=\"https://emokymai.vu.lt/course/view.php?id=2303#section-2\">Testai</a>\n"
    "\t\t\t\t</span>\n"
    "\t\t\t</h3>\n");
}
void section(FILE *linker)
{
    fprintf(linker, "%s", "\t\t<section class=\"main-container\">\n");
    head3(linker);
    fprintf(linker, "%s", "\t\t\t<div>\n"
    "\t\t\t\t<p id=\"miniTestTitle\" class=\"mini-test\">\n"
    "\t\t\t</div>\n"
    "\t\t\t<div id=\"content\" class=\"images-container\">\n"
    "\t\t</section>\n");
}