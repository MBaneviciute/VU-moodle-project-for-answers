#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"
#include "FAQ_CREATE.h"

void footer(FILE *linker)
{
    fprintf(linker, "%s", "\t<footer class=\"footer\">\n"
    "\t\t<small class=\"copyright\">\n"
    "\t\t\tCopyright © Vilnius University\n"
    "\t\t</small>\n"
    "\t</footer>\n");
}