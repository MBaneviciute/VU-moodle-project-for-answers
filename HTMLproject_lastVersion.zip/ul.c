#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"
#include "FAQ_CREATE.h"

void ul1(FILE *linker)
{
    fprintf(linker, "%s", "\t\t\t\t\t<ul class=\"bottom-bar-list\">\n"
    "\t\t\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">Home</a>\n"
    "\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">News</a>\n"
    "\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">Services</a>\n"
    "\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">All courses</a>\n"
    "\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">Archive</a>\n"
    "\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"faq.html\">FAQ</a>\n"
    "\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">English</a>\n"
    "\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t</ul>\n");
}
void ul2(FILE *linker)
{
    fprintf(linker,"%s","\t\t\t\t\t\t<ul class=\"course-list\">\n"
    "\t\t\t\t\t\t\t<li class=\"course-item\">\n"
    "\t\t\t\t\t\t\t\t<a class=\"course-link\" href=\"\">Dashboard</a>\n"
    "\t\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t\t<li class=\"course-item\">\n"
    "\t\t\t\t\t\t\t\t<a class=\"course-link\" href=\"\">/ My courses</a>\n"
    "\t\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t\t<li class=\"course-item\">\n"
    "\t\t\t\t\t\t\t\t<a class=\"course-link\" href=\"\">/ Programavimo pagrindai (I. Radavičius,paskaitos/pratybos</a>\n"
    "\t\t\t\t\t\t\t</li>\n"
    "\t\t\t\t\t\t</ul>\n");
}