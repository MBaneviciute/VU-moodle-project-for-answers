#ifndef _SECTION_
#define _SECTION_

#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"
#include "FAQ_CREATE.h"

#endif

void head3(FILE *);
void section(FILE *);