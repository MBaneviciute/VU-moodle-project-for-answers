#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"
#include "FAQ_CREATE.h"
#define SIZE 5
#define ARR_SIZE 1000

int main()
{
    FILE *fp;
    fp = fopen("C_project.html", "w");
    char *fileName = NULL;
    int index = 0, temp;
    char *title = (char *)malloc(sizeof(char) * ARR_SIZE);
    char *text = (char *)malloc(sizeof(char) * ARR_SIZE);
    int size = 0;
    char *arrFile[]  = {"1. minitestas 1\n","2. minitestas 2\n", "3. minitestas 3\n", "4. minitestas 4\n", "5. minitestas 5\n"};
    for(int i = 0; i < SIZE; ++i)
    {
        printf("%s",arrFile[i]);
    }
    while(1)
    {
        printf("Please enter the index of the desired test\n");
        if(scanf("%d",&index) == 1)
        {
                if(index > 0 && index <= SIZE)
                {
                    break;
                }
        }
        else
        {
            printf("The input was incorrect\n");
        }
        while((temp=getchar()) != EOF && temp != '\n');
        
    }
    switch(index)
    {
        case 1:
        fileName = "firstTestImages";
        break;

        case 2:
        fileName = "secondTestImages";
        break;

        case 3:
        fileName = "thirdTestImages";
        break;

        case 4:
        fileName = "fourthTestImages";
        break;

        case 5:
        fileName = "fifthTestImages";
        break;

    }

    char c;
    printf("the input was correct\n");
    printf("if you want to add a faq, question with the answer type 'y' if not type 'n'\n");
    while(1)
    {
        if(scanf("%c", &c) == 1)
        {   
            if(c == 'y')
            {
                printf("Please enter a questions in FAQ title\n");
                printf("{The max characters count is 150}\n");
                scanf("\n");
                scanf("%[^\n]%*c",title);
                printf("Please enter the text, of the FAQ\n");
                printf("{The max characters count is 150}\n");
                scanf("\n");
                scanf("%[^\n]%*c",text);
                faq(title, text);
                break;
            }
            else if(c == 'n')
            {
                title = "n";
                text = "n";
                faq(title, text);
                break;
            }
        }
        while((temp=getchar()) != EOF && temp != '\n');
        printf("the input was incorrect, please try again\n");
    }
    

        

    fprintf(fp,"%s","<!DOCTYPE html>\n");
    html(fp);

    script(fp,fileName,index);
    

    fclose(fp);
    free(fileName);
    free(title);
    free(text);
    return 0;
}