#include <stdio.h>
#include <stdlib.h>
#include "body.h"
#include "footer.h"
#include "head.h"
#include "HTML.h"
#include "script.h"
#include "section.h"
#include "ul.h"
#include "FAQ_CREATE.h"
#include <string.h>

void img2(FILE *name)
{
    fprintf(name,"\t\t\t\t\t<img class=\"vu-logo\"\n"
    "\t\t\t\t\t\tsrc=\"https://emokymai.vu.lt/pluginfile.php/1/theme_maker/logo/1634296690/VU_VMA_2%287%29%20%281%29.png\"\n"
    "\t\t\t\t\t\talt=\"vu logo\">\n");
}
void faq(char *title, char *text)
{
    FILE *fp;
    fp = fopen("faq.html", "w");
    fprintf(fp,"<!DOCTYPE html>\n"
    "<html lang=\"en\">\n");

    fprintf(fp,"<head>\n"
    "\t<meta charset=\"UTF-8\">\n"
    "\t<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n"
    "\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
    "\t<link rel=\"stylesheet\" href=\"styles.css\">\n"
    "\t<link=\" relshortcut icon\" href=\"https://emokymai.vu.lt/theme/image.php/maker/theme/1634296690/favicon\">\n"
    "\t<title>Course: Programavimo pagrindai (I.Radavičius, paskaitos/pratybos)</title>\n"
    "</head>\n");

    fprintf(fp,"<body>\n"
    "\t<div class=\"faq-page\">\n"
    "\t\t<header class=\"page-header\">\n"
    "\t\t\t<div class=\"top-bar\">\n"
    "\t\t\t</div>\n"
    "\t\t\t<div class=\"bottom-bar\">\n"
    "\t\t\t\t<div class=\"bottom-bar-container\">\n");
    img2(fp);
    fprintf(fp,"\t\t\t<ul class=\"bottom-bar-list\">\n"
    "\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"main.html\">Home</a>\n"
    "\t\t\t\t</li>\n"
    "\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">News</a>\n"
    "\t\t\t\t</li>\n"
    "\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">Services</a>\n"
    "\t\t\t\t</li>\n"
    "\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">All courses</a>\n"
    "\t\t\t\t</li>\n"
    "\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">Archive</a>\n"
    "\t\t\t\t</li>\n"
    "\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"faq.html\">FAQ</a>\n"
    "\t\t\t\t</li>\n"
    "\t\t\t\t<li class=\"bottom-bar-item\">\n"
    "\t\t\t\t\t<a class=\"bottom-bar-link\" href=\"https://emokymai.vu.lt/\">English</a>\n"
    "\t\t\t\t</li>\n"
    "\t\t\t</ul>\n"
    "\t\t\t</div>\n"
    "\t\t</div>\n"
    "\t\t</header>\n"
    "\t</div>\n");

    fprintf(fp,"\t<section class=\"faq-title-container\">\n"
    "\t\t<h1 class=\"faq-title\">Frequently asked questions</h1>\n"
    "\t\t<div class=\"faq-texts\">\n"
    "\t\t\t<p class=\"faq-text\">Dashboard /&nbsp;</p>\n"
    "\t\t\t<p class=\"faq-text\">Frequently asked questions</p>\n"
    "\t\t</div>\n"
    "\t</section>\n"
    "\t<section class=\"faq-container\">\n"
    "\t\t<div class=\"faq-content\">\n"
    "\t\t\t<h2 class=\"faq-main-title\">Frequently asked questions</h2>\n"
    "\t\t\t<p class=\"faq-examination\">Examination</p>\n"
    "\t\t\t<div>\n"
    "\t\t\t\t<ul class=\"faq-box-wrapper\" id=\"faq-box-wrapper\">\n"
    "\t\t\t\t</ul>\n"
    "\t\t\t</div>\n"
    "\t\t</div>\n"
    "\t</section>\n"
    );

    fprintf(fp,"\t <footer class=\"footer\">\n"
    "\t\t<small class=\"copyright\">Copyright © Vilnius University</small>\n"
    "\t</footer>\n"
    "</body>\n");

    if(strcmp(title,"n") != 0 && strcmp(text,"n") != 0)
    {
        fprintf(fp,"<script>\n"
        "const usersTitleInput = [\"%s\"];\n"
        "const usersTextInput = [\"%s\"];\n"
        "const usersTitleInputArray = [];\n"
        "const usersTextInputArray = [];\n"
        "usersTitleInput.map(item => {usersTitleInputArray.push(item);});\n"
        "usersTextInput.map(item => {usersTextInputArray.push(item);});\n"
        "const faqWrapper = document.getElementById('faq-box-wrapper');\n"
        "usersTitleInputArray.map((item, index) => {\n"
        "\tconst title = document.createElement('label');\n"
        "\tconst text = document.createElement('p');\n"
        "\tconst input = document.createElement('input');\n"
        "\tconst list = document.createElement('ul');\n"
        "\tconst liItem = document.createElement('li');\n"
        "\tfaqWrapper.appendChild(liItem);\n"
        "\tliItem.appendChild(input);\n"
        "\tliItem.appendChild(title);\n"
        "\tliItem.appendChild(text);\n"
        "\tinput.setAttribute(\"type\", \"checkbox\");\n"
        "\tinput.setAttribute(\"id\", \"question\");\n"
        "\tinput.setAttribute(\"name\", \"question\");\n"
        "\ttitle.setAttribute(\"for\", \"question\");\n"
        "\ttitle.className = \"faq-box-title\";\n"
        "\ttext.className = \"faq-box-text\";\n"
        "\tinput.className = \"questions\";"
        "\tlist.className = \"faq-box-wrapper\";\n"
        "\tliItem.className = \"faq-box\"\n"
        "\tconst additionalTitle = document.createTextNode(usersTitleInputArray[index]);\n"
        "\tconst additionalText = document.createTextNode(usersTextInputArray[index]);\n"
        "\ttitle.appendChild(additionalTitle);\n"
        "\ttext.appendChild(additionalText);\n"
        "});\n"
        "</script>\n"
        ,title,text);
    
    }
        
    fclose(fp);
}